import React from 'react';

const Test = () => (
    <div> test </div>        
)

export default Test;